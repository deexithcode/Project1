---
name: query-tests
description: Generate tests and assertions for a SQL model or PySpark transform — uniqueness, nulls, referential integrity, edge cases, and a small fixture. Use when the user says "write tests for this query", "this model has no tests", "add data quality checks", "what should I test here", or "unit test this transform".
---

# Query tests

Fewer tests that fail for real reasons beat full coverage that never fires.

## What to generate, in priority order
1. **The key.** `unique` + `not_null` on the primary or surrogate key. If the model
   has a key and no uniqueness test, that is the whole finding.
2. **The grain.** One assertion that proves it: a count-per-key check that fails
   the moment a join fans out.
3. **Referential integrity** on every foreign key that something joins to.
4. **Column contracts** — accepted values for enums, non-negative for amounts,
   date ranges that reject the year 1970 and the year 2999.
5. **The edge cases that actually occur here**, chosen from the query itself:
   empty input, a null in a join key, a duplicate in the source, late-arriving
   rows, a timezone boundary, division by zero.

## For PySpark transforms
A small inline fixture DataFrame plus assertions on the output. Cover: empty
input, one null in each nullable column, and one duplicate key. Three cases is
enough to start.

## Never
- Never generate a test that cannot fail (an `accepted_values` test passes on an
  empty column — pair it with `not_null` or it is decoration).
- Never write a fixture with a hundred rows when three prove the case.
- Never test the warehouse's own behaviour.

## Output
The test file, ready to paste, plus one line per test saying what breakage it catches.
