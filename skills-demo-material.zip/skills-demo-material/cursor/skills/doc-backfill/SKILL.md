---
name: doc-backfill
description: Write missing model, column, or function documentation from lineage and real call sites instead of guessing. Use when the user says "document this", "backfill docs", "add descriptions", "nothing is documented", or "write the column descriptions".
---

# Doc backfill

## Method
1. **Derive, don't invent.** Read where the thing is produced and every place it's consumed. The consumers tell you what it means.
2. State the **grain** in the model description. First sentence, always.
3. For each column: what it means, its unit or enum, and one gotcha if there is one.
4. Where you genuinely cannot tell, write `TODO(owner): ` — never write a plausible guess.

## Never
- Never restate the column name as its description ("order_id: the order id").
- Never document a column you could not trace. Flag it instead.

## Output
The YAML or docstring, ready to paste, plus a short list of what needs a human to answer.
