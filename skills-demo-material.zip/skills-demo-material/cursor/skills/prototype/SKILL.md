---
name: prototype
description: Answer one design question with throwaway code, then delete it — code whose only job is to resolve uncertainty. Use when the user says "prototype", "is this key stable", "does this work with real data", "quick check", or needs to validate a design assumption before committing.
---

# Prototype

Code whose only job is to answer one question. Then you delete it.

## Good questions
- Does this state model survive real data?
- Is the key actually stable across history?
- Does the API paginate the way the docs claim?
- Will this join fan out at production grain?

## Method
1. **State the one question** in one sentence before writing anything.
2. **Smallest code that answers it** — one query, one script, one curl. No error handling, no structure.
3. **Run it or show exactly what to run** against this repo's files when possible.
4. **Answer in one line:** yes / no / it depends on X.
5. **Say "prototype deleted, decision kept"** — the code was never the deliverable.

## Never
- Never build toward production — no tests, no config, no "while we're here".
- Never answer two questions in one prototype.
- Never leave the throwaway code without labeling it as throwaway.

## Output
The question · the minimal code · the one-line answer · what decision this unlocks.
