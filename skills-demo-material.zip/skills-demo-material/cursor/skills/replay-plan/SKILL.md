---
name: replay-plan
description: Plan a safe replay of a queue, topic, or event stream — ordering, dedupe, poison messages, stop conditions. Use when the user says "replay", "reprocess the queue", "re-consume the topic", "we need to resend", or "the consumer had a bug".
---

# Replay plan

## Always answer in writing first
1. **Window** — from which offset or timestamp, to which. Why those.
2. **Idempotency** — will a reprocessed message produce a duplicate side effect? Emails, charges, and webhooks are the ones that hurt.
3. **Ordering** — does the consumer depend on order? Replay usually breaks it.
4. **Poison messages** — what happens when the message that caused the original bug arrives again.
5. **Stop condition** — the metric that halts the replay automatically.

## Never
- Never replay into a consumer with side effects until idempotency is proven.
- Never replay the whole retention window when a bounded slice answers the question.
- Never run without a canary slice first.

## Output
The five answers above, then the exact commands, then the rollback.
