---
name: data-contract
description: Turn a source schema into an explicit data contract plus the tests that enforce it. Use when the user says "data contract", "define the schema", "what do we guarantee", "onboard this source", or "the source keeps changing on us".
---

# Data contract

## What a contract has to state
1. **Grain and key** — one row per what, identified by what.
2. **Per column**: type, nullability, allowed values, and whether it's PII.
3. **Freshness** — the SLA, and what "late" means.
4. **Change policy** — which changes are additive and allowed without notice, which require a version.
5. **Owner** — a team, not a person.

## Then generate the enforcement
Every guarantee above becomes a test. A guarantee with no test is a wish.

## Never
- Never write a contract without an owner.
- Never mark a column non-null unless the source actually guarantees it — check the data.

## Output
The contract as YAML, then the test file, then a list of guarantees you could not verify.
