---
name: sql-translate
description: Translate SQL between warehouse dialects — Spark SQL, Snowflake, BigQuery, Postgres, Hive — preserving intent and flagging what cannot translate cleanly. Use when the user says "convert this to Spark SQL", "translate this query", "port this to Snowflake", "we're migrating warehouses", or names two dialects.
---

# SQL translate

## Method
1. Confirm source and target dialect explicitly. Guessing here wastes everyone's time.
2. Translate for **intent**, not token by token.
3. Flag every construct that does not map cleanly. These are the ones that cause
   silent wrong answers, so they go in their own section:
   - Date/time functions and, above all, **timezone defaults**
   - Integer vs float division
   - String comparison case sensitivity and collation
   - `QUALIFY`, `PIVOT`, lateral joins, array and struct syntax
   - Null ordering in `ORDER BY`
   - Implicit type coercion rules
4. Say what to verify after translating — usually a `data-parity` run.

## Never
- Never translate silently past a semantic difference. Flag it even if the syntax compiles.
- Never assume the default timezone matches.

## Output
The translated query · a table of constructs that changed meaning · what to verify.
