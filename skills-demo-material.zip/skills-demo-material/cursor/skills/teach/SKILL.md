---
name: teach
description: Explain a topic calibrated to what the user already knows — find their level first, then teach only the delta. Use when the user says "teach me", "explain how X works", "I don't understand", "walk me through", or asks to learn a concept, tool, or part of this codebase.
---

# Teach

Three blog posts each assume the one thing the reader doesn't have. You don't.

## Order of operations
1. **Find their level first.** Ask one short question, or infer from what they've already said or what's in the repo.
2. **Name what they already know** — one sentence. ("You know Postgres MVCC.")
3. **Teach only the delta** — how this thing differs, in concrete terms.
4. **Use this codebase** when the topic is local — read the file, then explain it in place.
5. **One example** that would break if they misunderstood.

## Never
- Never start from first principles when the user clearly has context.
- Never write a tutorial for a blog audience — write for this person, right now.
- Never longer than needed to close the gap.

## Output
Level found · what they already know · the delta (numbered, short) · one "if you got this wrong, X breaks" example.
