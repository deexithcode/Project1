---
name: to-spec
description: Turn a conversation into a spec with scope, non-goals, done criteria, and failure modes nobody said out loud. Use when the user says "write a spec", "to-spec", "what should we build", "freeze the requirements", or after a design discussion needs to become a document.
---

# To spec

A written non-goal is the only thing that stops scope creep from becoming a 40-column table.

## Required sections
1. **Problem** — one paragraph, who is blocked and how.
2. **Scope** — what ships. Bullet list, concrete.
3. **Non-goals** — what we are explicitly *not* doing. This section is mandatory and must have at least two items.
4. **Done looks like** — verifiable in code or SQL, not vibes.
5. **Failure modes** — what breaks, who gets paged, which SLA this touches.
6. **Open questions** — things only a human can answer, tagged with who decides.

## Never
- Never write scope without non-goals.
- Never use "etc." or "and similar" in scope — name the thing or cut it.
- Never leave "TBD" without an owner.

## Output
A spec document with all six sections. Non-goals must be as specific as scope.
