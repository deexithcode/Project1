---
name: debug-spark
description: Diagnose a failing or hanging PySpark job from its stack trace, logs, or Spark UI symptoms — OOM, skew, spill, shuffle explosion, serialization and Py4J errors. Use when the user says "spark job failed", "OOM", "out of memory", "the job is stuck", "Py4J", "executor lost", "stage is hanging", or pastes a Spark stack trace.
---

# Debug Spark

Py4J traces bury the real error. The Java trace at the top is usually noise.

## Order of operations
1. **Find the real error.** Scroll to the last `Caused by:`, and to the Python
   traceback below the Java one. Report that, not the top line.
1b. **Read the job source.** A log tells you a stage failed; only the code tells
   you which key it partitioned on. If the job file is named or findable, open
   it before diagnosing — a symptom without the line that caused it is a guess.
2. **Identify the symptom class** before proposing anything:
   - `OutOfMemoryError` on the **driver** — a `collect()`, `toPandas()`, or a
     broadcast of something too big. Almost never fixed by more executor memory.
   - `OutOfMemoryError` on an **executor** — skew, or a partition too large.
   - `ExecutorLostFailure` / `Container killed by YARN` — memory overhead, usually
     off-heap or a fat UDF.
   - **Stage hangs at 199/200 tasks** — textbook skew. One key owns the data.
   - **Shuffle spill to disk** — partition count wrong for the data volume.
   - `PicklingError` / `Task not serializable` — a connection or client captured
     in a closure.
3. **Check the cheap explanations first**: is AQE on? Is the default
   `spark.sql.shuffle.partitions` (200) wrong for this data size?
4. Only then propose a code or config change.

## Never
- Never say "increase executor memory" as the first fix. It hides skew and costs money.
- Never propose a config change without naming the symptom it addresses.
- Never suggest `.cache()` as a performance fix without checking the job is read-twice.

## Output
Real error (with the line you found it on) · symptom class · root cause · smallest fix ·
what to check in the Spark UI to confirm.
