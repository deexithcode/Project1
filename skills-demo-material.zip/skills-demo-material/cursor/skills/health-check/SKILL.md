---
name: health-check
description: Decide whether a service is actually broken or merely degraded — read SLOs and error budgets before reading code. Use when the user says "is this broken", "are we down", "check the health of", "should I page someone", or "is it just slow".
---

# Health check

## Order of operations
1. Read the SLO first. "Slow" is only an incident relative to a target.
2. Compare against the error budget, not against yesterday.
3. Separate **user-visible** from **internal** symptoms. Only the first justifies a page.
4. Check whether a deploy, a config change, or a traffic change lines up in time.

## Never
- Never declare an incident from a single graph.
- Never page on a symptom you cannot tie to a user impact.

## Output
Verdict (healthy / degraded / down) · the SLO it's measured against · what changed · whether to page.
