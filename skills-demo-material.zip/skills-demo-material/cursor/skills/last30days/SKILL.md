---
name: last30days
description: Research what practitioners actually say about a tool or approach in the last 30 days — upvotes, counter-signals, and a bounded verdict. Use when the user says "last30days", "what are people saying about", "should we adopt", "is X production-ready", or is choosing between tools where model knowledge has a cutoff.
---

# Last 30 days

Model knowledge has a cutoff. Vendor decisions shouldn't.

## Method
1. **Search recent sources** — Reddit, HN, X, engineering blogs, release notes from the last 30 days. Use web search when available.
2. **Collect signals**, not summaries:
   - what got upvoted / repeated
   - what broke in production (memory, cost, ops burden)
   - who is actually using it vs blogging about it
3. **Surface counter-signals explicitly.** The skill is untrustworthy without them.
4. **Verdict is bounded** — "great under X, don't bet the platform on Y" — not "it's popular".

## Never
- Never cite posts older than 30 days unless they're the only data and you say so.
- Never recommend adoption without naming the failure mode people hit.
- Never hide that you couldn't search — say what you'd look for instead.

## Output
**Signals** (3–5 bullets, with source type) · **Counter-signals** (at least one) · **Verdict** (one paragraph, bounded, actionable).
