---
name: lineage-diff
description: Compare column-level lineage between two versions of a query or model to show which columns were added, removed, or now come from somewhere else. Use when the user says "what changed in this model", "lineage diff", "where does this column come from now", or reviews a PR that rewrites a query.
---

# Lineage diff

## Method
1. Build the column-level map for each version: for every output column, the
   source columns and transformations that produce it.
2. Diff them into three buckets:
   - **Added** — new output columns.
   - **Removed** — columns downstream may still be selecting. Check who reads them.
   - **Re-sourced** — same column name, different origin. This is the dangerous
     one: nothing fails, the meaning just changes.
3. For re-sourced columns, say what could differ in practice — a different join
   path, a different null behaviour, a different grain.

## Never
- Never report only added and removed. Re-sourced is where the incidents come from.
- Never assume a same-named column means the same thing.

## Output
Three lists · for each re-sourced column, what could now differ · who to warn.
