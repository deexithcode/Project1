---
name: visual-plan
description: Turn a plan into a shareable page — diagram, file map, annotated code, open questions — before anyone writes real code. Use when the user says "visual-plan", "plan this change", "approval gate", "schema migration plan", or when the wrong direction is expensive (multi-file, re-platform, schema change).
---

# Visual plan

The plan stops being buried prose in a chat log and becomes a page someone can veto.

## Required on the page
1. **Diagram** — what changes, before/after or data flow. Use mermaid or HTML boxes, not ASCII.
2. **File map** — every file this will touch, grouped by layer.
3. **Annotated code sketch** — the critical lines, not a full implementation.
4. **Open questions** — tagged with who must answer before coding starts.
5. **Rollback** — how to undo if the first deploy fails.

## Never
- Never skip open questions — they're the point.
- Never present a plan without naming blast radius.
- Never write production code — this is the approval gate, not the build.

## Output
A single markdown or HTML page with all five sections. End with: *"Share this link before writing real code."*
