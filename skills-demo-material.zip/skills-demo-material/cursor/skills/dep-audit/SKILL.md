---
name: dep-audit
description: Audit dependencies — what's unused, what's duplicated, what could be replaced by the standard library. Use when the user says "dependency audit", "do we need all these packages", "audit requirements", "reduce our dependencies", or "why is the image so big".
---

# Dep audit

## Method
1. For each declared dependency, find a real import. No import is the strongest finding.
2. Find **duplicates of purpose** — two HTTP clients, two date libraries.
3. Find dependencies replaceable by the standard library in a few lines.
4. Only then look at versions and vulnerabilities.

## Never
- Never recommend adding a dependency for something a few lines of stdlib does.
- Never remove something used only in tests or only at build time without saying so.

## Output
Three lists: **unused** · **duplicated purpose** · **stdlib would do**. Each with the file evidence.
