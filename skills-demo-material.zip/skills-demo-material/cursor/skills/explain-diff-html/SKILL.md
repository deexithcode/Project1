---
name: explain-diff-html
description: Turn a diff, commit, or PR into a self-contained HTML page — background, intuition, code walkthrough, quiz — for onboarding. Use when the user says "explain this diff", "explain-diff-html", "onboarding page for this PR", or wants a rich explanation of what changed and why.
---

# Explain diff HTML

Best use: onboarding. The PR that changed how writes work explains itself to the next hire.

## Before writing
1. Get the full diff — `git diff`, `git show`, or `gh pr diff`. Don't write from the title alone.
2. Read files adjacent to changed lines.
3. Note what the PR does **not** change — scope boundaries matter.

## Required sections (in order)
1. **Background** — beginner layer (skippable) + change-specific layer.
2. **Intuition** — the core idea in plain language, one concrete example.
3. **Code walkthrough** — grouped by theme, not alphabetical file list.
4. **Quiz** — five multiple-choice questions, medium difficulty. Plausible distractors. Feedback on each answer.

## Format
- Single self-contained HTML file — CSS and JS inline, no CDN, works offline.
- Save outside the repo: `/tmp/YYYY-MM-DD-explanation-<slug>.html`
- Print the absolute path when done.
- Support dark mode via `prefers-color-scheme`.

## Never
- Never skip the "why" — the diff shows what; the page explains why.
- Never make quiz answers guessable by length alone.
- Never commit the HTML file to the repo.

## Output
The file path · one-sentence summary of what changed · who should read it.
