---
name: pii-scan
description: Classify columns and fields as PII and flag unmasked personal data before it ships or leaves the warehouse. Use when the user says "PII", "personal data", "is this sensitive", "GDPR", "privacy review", or is adding a new source, export, or API response.
---

# PII scan

## Method
1. Classify by **name and content pattern**, not name alone. `notes` and `comment` columns hide the worst of it.
2. Trace **exits**, not just storage: API responses, reverse-ETL syncs, CSV exports, logs, and error messages.
3. Rank by exit. PII sitting in a restricted raw table is a lower finding than the same field in a webhook payload.
4. Check `conventions.md` for the repo's own PII list and handling rules.

## Never
- Never report only column names — an unmasked field in an outbound sync is the actual finding.
- Never propose deletion as the only option; masking, tokenizing, and restricting are usually what's wanted.

## Output
A table: field · classification · where it exits · risk · the fix. Highest-exposure first.
