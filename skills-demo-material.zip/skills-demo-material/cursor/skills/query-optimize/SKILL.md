---
name: query-optimize
description: Make a slow or expensive SQL query faster — partition pruning, predicate pushdown, join order and strategy, spill and skew. Use when the user says "this query is slow", "optimize this query", "why is this expensive", "the warehouse bill went up", "reduce bytes scanned", or pastes a query plan.
---

# Query optimize

## Method
1. **Ask what it costs now.** Bytes scanned, wall time, or the plan. Optimizing
   without a baseline is guessing — if there is no number, say so and ask for one.
2. **Read the plan bottom-up.** The biggest scan and the biggest exchange are
   almost always the answer. Ignore everything else until those are addressed.
3. Work the levers in this order — cheapest change first:
   - **Prune.** Partition/cluster filter on the scan. This is usually the whole fix.
   - **Push down.** Filter before the join, not after. Aggregate before the join
     when the join key survives.
   - **Shrink.** Select the columns you need. On columnar storage this is real money.
   - **Join strategy.** Small side broadcastable? Both sides bucketed on the key?
   - **Skew.** One key dominating: salt it, or split hot keys out and union back.
4. State the expected saving for each change, and say which one you'd do alone.

## Never
- Never recommend a rewrite when a `WHERE` on the partition column does it.
- Never suggest an index/cluster key without saying what it costs to maintain.
- Never optimize a query whose results are already wrong — send it to `sql-review` first.

## Output
Baseline · ranked changes with expected saving · the one-line version if they only do one thing.
