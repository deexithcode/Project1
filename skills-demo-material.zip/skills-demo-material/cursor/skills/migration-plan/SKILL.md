---
name: migration-plan
description: Plan a safe schema, contract, or API migration — expand/migrate/contract ordering, backfill, rollback. Use when the user says "migration", "alter table", "rename this column", "change this contract", "add a required field", or "deprecate this endpoint".
---

# Migration plan

## Always ask first
1. Can the old and new shapes coexist for one release? If not, say why not before proposing anything.
2. Who are the consumers, and which do we not control?
3. Is the data change idempotent and re-runnable?
4. What does rollback cost after each step?

## The shape
Always three phases, never one:
- **Expand** — add the new thing, write both, read old.
- **Migrate** — backfill, move readers over one at a time.
- **Contract** — drop the old thing, only after readers are confirmed moved.

## Never
- Never ship a destructive change in a single step.
- Never make a new field required in the same release that adds it.
- Never assume a consumer you cannot see has migrated.

## Output
Numbered steps, each with: the change, who it can break, how to verify it worked, and how to roll it back.
