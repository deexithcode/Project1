---
name: to-tickets
description: Slice a spec into issues sized for one sitting, in dependency order, each with its own acceptance check. Use when the user says "to-tickets", "break this into tickets", "create issues", "slice the work", or has a spec that needs to become mergeable PRs.
---

# To tickets

The tell of a good slice: it can merge on its own without breaking anything downstream.

## Method
1. Read the spec (or ask for it). Non-goals are boundaries — don't ticket them.
2. **Order by dependency** — what blocks what.
3. **Size for one sitting** — ~2–4 hours each. If bigger, split.
4. Each ticket gets:
   - title (verb + noun)
   - what it delivers
   - **blocks:** none | #NNN
   - **acceptance check** — one verifiable sentence
   - flag `#needs-approval` when it touches prod data, backfills, or irreversible changes
5. Number sequentially.

## Never
- Never create a ticket that can't be verified.
- Never hide a risky ticket in a bundle of safe ones.
- Never ticket work that contradicts a non-goal.

## Output
Numbered ticket list in dependency order. Each ticket: title · deliverable · blocks · time estimate · acceptance check.
