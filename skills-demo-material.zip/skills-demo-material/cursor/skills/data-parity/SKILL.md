---
name: data-parity
description: Prove two queries, tables, or job versions return the same data — row counts, column-level diffs, aggregate totals, sample mismatches. Use when the user says "did my rewrite change anything", "compare these two tables", "data parity", "regression check", "validate the migration", or "the numbers moved".
---

# Data parity

The point is not "are they equal". It's **where and why they differ**.

## Method — always in this order
1. **Row counts** on both sides, plus counts by the natural partition (usually date).
   A whole-table count that matches can still hide a shifted window.
2. **Key set diff.** Keys in A not in B, and B not in A. Cap the output and show
   a handful of examples, not the whole list.
3. **Column-level diff** on the shared keys. Report per column: how many rows
   differ, and the max absolute and relative delta.
4. **Aggregate totals** for anything anyone reports on — revenue, counts, distinct
   users. These are what someone will notice on a dashboard.
5. **Classify each difference**: expected (a deliberate fix), tolerable (float
   rounding, ordering), or a **regression**.

## Never
- Never report "they differ" without an example row.
- Never let float equality drive the verdict — state a tolerance and use it.
- Never declare parity from row counts alone.

## Output
The comparison SQL first, so they can re-run it. Then the verdict per column.
Then one line: **safe to swap** or **do not swap**, and why.
