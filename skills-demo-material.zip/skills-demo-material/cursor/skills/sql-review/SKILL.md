---
name: sql-review
description: Pre-merge review of a SQL query or model for correctness, cost, and readability — grain, join fan-out, null handling, window frames, anti-patterns. Use when the user says "review this query", "review this SQL", "review my model", "does this look right", "SQL review", or pastes a query before merging it.
---

# SQL review

Read `conventions.md` first if it exists. Its rules beat generic best practice.

## Review in this order — correctness before cost
1. **Grain.** State it in one sentence: "one row per ___". If you cannot, that is
   finding #1 and everything below is unreliable.
2. **Join fan-out.** For every join, does the grain change? A `left join` to a
   many-side silently multiplies rows, and every `sum()` downstream is then wrong.
3. **Null semantics.** `NOT IN` with a null returns nothing. `!=` drops nulls.
   `count(col)` skips them, `count(*)` doesn't. Check every filter on a nullable column.
4. **Window frames.** An `ORDER BY` in a window with no explicit frame defaults to
   `RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW` — usually not what was meant.
5. **Dedupe honesty.** A `DISTINCT` or `row_number() = 1` hiding a real duplication
   bug is a finding, not a fix.
6. **Cost.** Partition/cluster filter present? Predicates pushed below the join?
   Incremental models guarded by `is_incremental()`?
7. **Readability.** CTE names that say what, not `cte1`. No SELECT * in a model.

## Never
- Never approve a query whose grain you could not state.
- Never call `DISTINCT` a fix.
- Never quote generic best practice when `conventions.md` disagrees.

## Output
Blockers first, then warnings, then nits. Each: the line, what breaks, the fix.
End with one line — **ship** or **fix first**.
