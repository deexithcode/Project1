---
name: triage
description: Diagnose a failing service, job, or deploy — find the first failure, name the cause, propose the smallest fix. Use when the user says "it's broken", "triage this", "we got paged", "why did this fail", "prod is down", or pastes an error log or stack trace.
---

# Triage

Nothing here is specific to services or pipelines. Same file works for both.

## Order of operations
1. Find the **first** failure, not the last one. Later errors are usually consequences.
2. Read **its** logs — not the dashboard, not the summary.
3. Classify the failure: `late` | `wrong` | `absent`.
4. Check upstream health before blaming our own code.
5. Only now propose a fix.

## Never
- Never restart, re-run, or redeploy before step 3.
- Never "just full-refresh it" or "just clear the cache".
- Never page a second team on a guess.

## Output
Four sections, in this order, nothing else:
- **Cause** — one sentence, naming the specific thing.
- **Blast radius** — who is affected and since when.
- **Smallest fix** — the minimum change that stops the bleeding, plus the real fix if different.
- **Who to tell** — and whether this needs a postmortem.
