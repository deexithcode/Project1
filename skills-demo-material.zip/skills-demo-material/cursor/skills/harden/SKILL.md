---
name: harden
description: Turn working-but-fragile code into something safe to run in production — timeouts, retries, limits, idempotency, and the tests it never had. Use when the user says "harden this", "make this production ready", "ship this properly", "this is a prototype", or "what's missing before we deploy".
---

# Harden

Read `conventions.md` first if it exists — the defaults there win over mine.

## The checklist, in order of what actually causes incidents
1. **Idempotency** on every write path.
2. **Timeouts** on every outbound call. Then retries with backoff — never retries without a timeout.
3. **Limits** — pagination, max page size, max payload, max memory.
4. **Failure behaviour** — what the caller sees when a dependency is down.
5. **One test per branch that can lose data.** Not full coverage. The data-loss paths.

## Never
- Never add a retry to something without a timeout — you've built an amplifier.
- Never add observability instead of a fix.
- Never gold-plate: no metrics dashboard for a job that runs once a week.

## Output
Ranked gaps, each with the smallest change that closes it. Say explicitly what you chose *not* to add.
