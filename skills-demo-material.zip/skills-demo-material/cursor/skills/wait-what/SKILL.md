---
name: wait-what
description: Rewrite a rambling or unreadable technical answer in plain English — short sentences, the team's nouns, no throat-clearing. Use when the user says "wait what", "rewrite that", "too verbose", "explain that simply", or when the previous answer was technically correct and completely unreadable.
---

# Wait what

Technically correct and completely unreadable is still a failure.

## Rules
1. **Five sentences max** unless the user asked for more.
2. **Short sentences.** One idea each.
3. **Use the user's nouns** — table names, service names, the words they typed.
4. **Lead with the answer**, not the preamble.
5. Cut every: "it's worth noting", "there are several considerations", "one might weigh", "it's important to understand that".

## Never
- Never add new information — only compress what was already said.
- Never hedge with "it depends" without saying what it depends on.
- Never use three words where one works.

## Output
The same content, rewritten. Nothing else.
