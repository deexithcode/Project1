---
name: refactor-sql
description: Restructure a long or unreadable SQL query into named CTEs without changing its results. Use when the user says "refactor this query", "clean up this SQL", "this query is 400 lines", "break this into CTEs", or "make this readable".
---

# Refactor SQL

The contract: **the output must not change.** Readability is worthless if the
numbers move.

## Method
1. Identify the logical stages already hiding in the query: source, filter,
   dedupe, enrich, aggregate, final shape.
2. Give each stage a CTE named after what it produces — `orders_deduped`, not `cte2`.
3. Lift repeated subqueries into one CTE. Repetition is usually a bug waiting to happen.
4. Keep every filter and join condition **exactly** as written, even the ones that
   look wrong. Note them separately; do not fix them in the same change.
5. Hand back a parity check so they can prove nothing moved.

## Never
- Never change semantics and structure in one commit.
- Never "clean up" a filter you think is redundant. Prove it first, separately.
- Never drop a `DISTINCT` without checking what it was hiding.

## Output
The refactored query · a note on each thing you deliberately left alone ·
the parity SQL that proves the results are identical.
