---
name: model-review
description: Review a data model for grain, keys, nulls, tests, and naming against this repo's own conventions. Use when the user says "review this model", "model review", "is this table right", "check my dbt model", or opens a PR touching models.
---

# Model review

Read `conventions.md` first. Its rules override anything here.

## Checks, in this order
1. **Grain** — state it in one sentence. If the model has no stated grain, that's finding #1.
2. **Keys** — every `_sk` has `unique` + `not_null`. Missing uniqueness test on a surrogate key is always a blocker.
3. **Joins** — does any join change the grain? If yes, is that intentional and documented?
4. **Nulls** — which columns can be null, and does anything downstream assume otherwise?
5. **Docs** — model description and column descriptions present.
6. **Naming** — matches the conventions file, not general best practice.

## Never
- Never pass a model with an untested surrogate key.
- Never quote generic best practice when the conventions file says otherwise.

## Output
`✓` / `✗` per check, blockers first, each with the exact line to add.
