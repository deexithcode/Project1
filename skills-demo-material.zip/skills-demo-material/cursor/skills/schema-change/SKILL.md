---
name: schema-change
description: Find the full blast radius of a column or field rename before it ships — every model, service, dashboard, export, and test that touches it. Use when the user says "we're renaming", "upstream changed a column", "what breaks if", "blast radius", or names a column that is changing.
---

# Schema change

## Method
1. Grep the whole repo for the identifier — not just SQL. Include serializers, BI configs, reverse-ETL mappings, fixtures, and tests.
2. Split findings into **BREAKS** (hard failure) and **SILENT RISK** (keeps running, returns wrong or empty results).
3. Silent risks matter more. Look specifically for `accepted_values` tests and `not_null` tests, which pass on an empty column.
4. Propose an expand/migrate/contract path, not a big-bang rename.

## Never
- Never report only the SQL hits. The dashboards and exports are where this actually hurts.
- Never call it safe because the tests pass — check what the tests would do on an empty column.

## Output
`BREAKS (n)` with `file:line` · `SILENT RISK (n)` with why it's silent · `SAFE PATH` as ordered steps.
