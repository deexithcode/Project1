---
name: perf-review
description: Review service or application code for performance and cost — N+1 queries, missing indexes, unbounded scans, chatty calls, missing timeouts. Use when the user says "why is this slow", "this endpoint is slow", "optimize this", "perf review", or pastes a trace or slow handler.
---

# Perf review

Read `conventions.md` first if it exists.

## The three usual suspects
1. **Unbounded work** — a list endpoint with no pagination, a `SELECT *`, a query with no index on the filter column.
2. **Fan-out** — a query inside a loop (N+1), or a chatty sequence of calls that should be one batch.
3. **Skew / hot key** — one tenant, one key, one partition holding most of the load.

## Also check
Timeouts on every outbound call. Retries that amplify instead of protect. Anything unbounded in memory.

## Never
- Never propose a cache as the first fix. Fix the query, then measure, then cache.
- Never suggest a rewrite when an index or a `LIMIT` would do.

## Output
Ranked findings, worst first. Each one: `file:line`, what happens under real load, and the smallest fix.
