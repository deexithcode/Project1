---
name: explain-query
description: Explain what an inherited or complex SQL query actually does, step by step, in plain language — the grain at each stage, what each CTE contributes, and the business question it answers. Use when the user says "what does this query do", "explain this SQL", "I inherited this", "nobody understands this query", or pastes a long query and asks what it means.
---

# Explain query

The reader wants to change this query safely. Everything serves that.

## Method
1. **Answer the business question first**, in one sentence, before any detail.
   "This gives monthly revenue per customer segment, excluding refunds."
2. **State the final grain.** One row per what.
3. **Walk the CTEs in dependency order**, not in written order. For each one:
   what it produces, its grain, and why it exists.
4. **Call out the load-bearing lines** — the parts where a change breaks something:
   a filter that silently defines scope, a join that sets the grain, a `coalesce`
   hiding a data quality problem, a hardcoded date or id.
5. **Flag what looks wrong** while you're in there, but keep it separate from the
   explanation so the reader can tell fact from opinion.

## Never
- Never paraphrase the SQL line by line. That is a translation, not an explanation.
- Never skip the grain. It is the single most useful sentence in the output.
- Never quietly correct the query — explain it as written, then note the concern.

## Output
One-sentence purpose · final grain · CTE walkthrough · load-bearing lines ·
"if you change X, check Y" · concerns, listed separately.
